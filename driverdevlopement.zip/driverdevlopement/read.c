#include<stdio.h>
#include<stdlib.h>
#include<stdint.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argc, char** argv){

    int fd,nbytes;
    fd=open("/dev/psample",O_RDONLY);
    printf("Return value for fd is %d\n",fd);
    if(fd<0){
        perror("open");
        exit(0);
    }
    int maxlen=128;
    char readbuf[maxlen];
    nbytes=read(fd,readbuf,maxlen);
    if(nbytes<0){
        perror("read");
    }
    readbuf[nbytes]='\0';
    printf("\nnbytes:%d \nbuf=%s \n",nbytes,readbuf);
    write(STDOUT_FILENO,readbuf,nbytes);
    close(fd);
    return 0;
}


