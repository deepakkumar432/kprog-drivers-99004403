#include<linux/fs.h>
#include<linux/init.h>
#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/cdev.h>
#include<linux/device.h>

dev_t pdevid;
struct cdev cdev;
int ndevices=1;

struct device *pdev;
struct class *pclass;

int pseudo_open(struct inode* inode,struct file* file)
{
	printk("Pseudo-Open method \n");
	return 0;
};

int pseudo_close(struct inode* inode,struct file* file)
{
	printk("Pseudo-Close method \n");
	return 0;
};

ssize_t pseudo_read(struct file* file,char __user *buf,size_t size, loff_t *off)
{
	printk("Pseudo-Read method \n");
	return 0;
};

ssize_t pseudo_write(struct file* file,const char __user *buf,size_t size, loff_t *off)
{
	printk("Pseudo-Write method \n");
	return -ENOSPC;
};

struct file_operations fops = {

.open		=	pseudo_open,
.release	=	pseudo_close,
.write		=	pseudo_write,
.read		=	pseudo_read

};

static int __init pseudo_init(void)
{
	int ret,i=0;
	pclass=class_create(THIS_MODULE,"pseudo_class");
	ret=alloc_chrdev_region(&pdevid,0,ndevices,"pseudo_sample");
	if (ret){

		printk("Psuedo: Failed to register driver\n");
		return -EINVAL;
		}
	cdev_init(&cdev,&fops);
	kobject_set_name(&cdev.kobj,"pdevice%d",i);
	ret=cdev_add(&cdev,pdevid,1);
	if (ret){

		printk("Psuedo: Failed to register device\n");
		return -EINVAL;
		}
	pdev=device_create(pclass,NULL,pdevid,NULL,"psample%d",i);

printk("Successfully registered,major = %d ,minor = %d",MAJOR(pdevid),MINOR(pdevid));
printk("Pseudo Driver Sample ..welcome\n");
return 0;
}
static void __exit pseudo_exit(void)
{
	unregister_chrdev_region(pdevid,ndevices);
	cdev_del(&cdev);
	device_destroy(pclass,pdevid);
	class_destroy(pclass);
	printk("Pseudo driver sample bye \n");
}

module_init(pseudo_init);
module_exit(pseudo_exit);

MODULE_AUTHOR("DEEPAK KUMAR");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Step 3 drivers");

